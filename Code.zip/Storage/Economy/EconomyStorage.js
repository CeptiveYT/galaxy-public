const e = require("./Storage.json");

// this is the element/variable we will be using in our test command 
const EconomyStorage = {
    items: e.items,
    pays: e.pays
}

module.exports = {
    EconomyStorage
};