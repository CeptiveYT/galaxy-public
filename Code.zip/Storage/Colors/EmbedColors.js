const invisible = "#ff66a7"; 

module.exports = {
    invisible
}