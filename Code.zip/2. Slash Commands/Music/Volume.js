const { Client, CommandInteraction, MessageEmbed } = require("discord.js")
const guildSchema = require("../../Storage/Schemas/guildSchema");
const { PremiumGuild } = require("../../Storage/Schemas/premiumSchema")

module.exports = {
    name: "volume",
    description: "⭐ Set the volume of the music playing.",
    enabled: true,
    options: [
        {
            name: "percent",
            type: 4,
            description: "10 = 10%",
            required: true
        }
    ],
    /**
     * @param {CommandInteraction} interaction
     * @param {Client} client
     */
    async execute(interaction, client) {
        let MyServer = await guildSchema.findOne({
            serverID: interaction.guild.id
        });

        const {
            guild, 
            member, 
            channel, 
            options
        } = interaction; 

        let premium = await PremiumGuild.findOne({ ServerID: interaction.guild.id });
        if (!premium) return interaction.reply({
            embeds: [
                new MessageEmbed({
                    author: { name: "This command is limited to premium guilds only." },
                    description: "Buy Galaxy Premium Here - [Buy Premium](https://discord.com/channels/990391641930100756/1009213365782065222)"
                })
            ]
        })

        if (MyServer) {

            const VoiceChannel = member.voice.channel;
            if (!VoiceChannel) return interaction.reply({
                embeds: [
                    new MessageEmbed({
                        description: "You must be in a voice channel before using this command.",
                        color: "RED"
                    })
                ]
            });

            const Volume = options.getInteger("percent");
            if (Volume > 100 || Volume < 1) return interaction.reply({
                embeds: [
                    new MessageEmbed({
                        color: "RED", description: "Please specify a number between 1 and 100."
                    })
                ]
            });

            client.distube.setVolume(VoiceChannel, Volume);
            await interaction.reply({
                        embeds: [
                            new MessageEmbed({
                                color: "LUMINOUS_VIVID_PINK", description: `🔊 Volume has been set to **${Volume}%**`
                            })
                        ]
                    })

        } else {
            return interaction.reply("Please set up galaxy bot first. `/setup`");
        }
    }
}
