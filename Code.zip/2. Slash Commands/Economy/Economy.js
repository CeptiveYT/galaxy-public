const {
  Client,
  MessageEmbed,
  CommandInteraction
} = require("discord.js");
const guildSchema = require("../../Storage/Schemas/guildSchema");
const {
  EconomyStorage
} = require("../../Storage/Economy/EconomyStorage");
const {
  Economy,
  User,
  CryptoPrices
} = require("../../Storage/Schemas/Economy/Economy");
const {
  generate
} = require("better-output");

module.exports = {
  name: "economy",
  description: "Complete Economy System (Setup and settings only) ",
  permission: "ADMINISTRATOR",
  enabled: true,
  options: [{
      name: "create",
      description: "create a new economy.",
      type: 1,
      options: [{
          name: "currency",
          description: "Set the currency to anything you want",
          type: 3,
          required: true,
        },
        {
          name: "economy-name",
          type: 3,
          description: "Name your Economy",
          required: false,
        },
      ],
    },
    {
      name: "set-currency",
      type: 1,
      description: "Set your economy's currency.",
      options: [{
        name: "new-currency",
        type: 3,
        description: "Your economy's new currency",
        required: true,
      }, ],
    },
    {
      name: "information",
      type: 1,
      description: "Get the economy information"
    },
    {
      name: "add-money",
      type: 1,
      description: "Add some money to a users profile.",
      options: [{
          name: "user",
          type: 6,
          description: "Select a user",
          required: true
        },
        {
          name: "type",
          type: 3,
          description: "Select what place you want the money to go to. (bank, balance)",
          required: true,
          choices: [{
              name: "bank",
              value: "bank"
            },
            {
              name: "balance",
              value: "balance"
            }
          ]
        },
        {
          name: "amount",
          type: 4,
          description: "The amount of money you want to add.",
          required: true
        }
      ]
    }
  ],
  /**
   *
   * @param {CommandInteraction} interaction
   * @param {Client} client
   */
  async execute(interaction, client) {
    let MyServer = await guildSchema.findOne({
      serverID: interaction.guild.id,
    });

    if (MyServer) {
      const {
        options,
        guild
      } = interaction;

      const sub = options.getSubcommand();
      const MyEconomy = await Economy.findOne({
        serverID: guild.id,
      });

      const successEmbed = new MessageEmbed({
        color: "GREEN",
      });

      const errorEmbed = new MessageEmbed({
        color: "RED",
      });

      switch (sub) {
        case "create": {
          if (MyEconomy) {
            errorEmbed.setDescription("You already have an economy created.");
            return interaction.reply({
              embeds: [errorEmbed],
              ephemeral: true,
            });
          } else {
            const currency = options.getString("currency");

            let name = options.getString("economy-name");
            if (!name) name = `${guild.name}`;
            let i = generate.ranString(30);

            await Economy.create({
              EconomyID: i,
              serverID: guild.id,
              ownerID: guild.ownerId,
              currency: currency,
              EconomyName: name,
              Data: {
                totalValue: 100000,
                totalUsers: 0,
              },
            }).then(() => {
              successEmbed.setDescription("A new economy has been created.");
              interaction.reply({
                embeds: [successEmbed],
                ephemeral: true
              });
            });
          }
        }
        break;
      case "set-currency": {
        if (MyEconomy) {
          const currency = options.getString("new-currency");

          await MyEconomy.updateOne({
            currency: currency,
          });

          successEmbed.setDescription(
            `You have set the new currency for your economy as \`${currency}\``
          );

          interaction.reply({
            embeds: [successEmbed],
            ephemeral: true
          });
        } else {
          errorEmbed.setDescription(
            "You need to set up an economy first. `/economy create`"
          );
          return interaction.reply({
            embeds: [errorEmbed],
            ephemeral: true,
          });
        }
      }
      break;
      case "information": {

        if (MyEconomy) {

          let TotalUsers = await MyEconomy.Data.totalUsers;

          const users = await User.find({
            serverID: interaction.guild.id
          }).then(users => {
            return users.filter(async user => {
              await interaction.guild.members.fetch(user.userID);
            });
          })

          const sortedUsers = users.sort((a, b) => {
            return (b.wallet.bank + b.wallet.balance) - (a.wallet.bank + a.wallet.balance)
          }).slice(0, 3);

          const embed = new MessageEmbed({
            title: `${MyEconomy.EconomyName} Econonomy Information`,
            color: "LUMINOUS_VIVID_PINK",
            description: '**"**_A great Economy requires great strength_**"**',
            fields: [{
                name: "__General__",
                value: `**Economy ID:** \`${MyEconomy.EconomyID}\` \n**Economy Name:** \`${MyEconomy.EconomyName}\` \n**Economy Owner:** <@${interaction.guild.ownerId}>`,
                inline: false
              },
              {
                name: "__Economy Stats__",
                value: `**Total Worth:** **${MyEconomy.currency} ${MyEconomy.Data.totalValue}**\n**Total Users:** **${TotalUsers}**\n\n**Top 3 Richest People**\n${sortedUsers.map((user, index) => {
                  return `**${index + 1}.** <@${user.userID}> - **${MyEconomy.currency} ${user.wallet.balance + user.wallet.bank}**`
                }).join("\n")}`,
                inline: false
              }
            ]
          })

          interaction.reply("^").then(() => {
            setTimeout(() => {
              interaction.deleteReply();
            }, 250);
          })

          interaction.channel.send({
            embeds: [embed]
          });

        } else {
          errorEmbed.setDescription(
            "You need to set up an economy first. `/economy create`"
          );
          return interaction.reply({
            embeds: [errorEmbed],
            ephemeral: true,
          });
        }

      }
      break;

      case "add-money": {

        let SelectedUser = options.getUser("user");
        let amount = options.getInteger("amount");
        let type = options.getString("type");

        switch (type) {
          case "bank": {

            let user = await User.findOne({
              serverID: guild.id,
              userID: SelectedUser.id
            });
            if (!user) return interaction.reply({
              embeds: [
                errorEmbed.setDescription("The user you have selected does not have an account set up in your economy.")
              ],
              ephemeral: true
            });
            if (amount <= 0) return interaction.reply({
              embeds: [
                errorEmbed.setDescription("You need to enter a number that is at least 1")
              ],
              ephemeral: true
            });

            await user.updateOne({
              $inc: {
                "wallet.bank": amount
              }
            }).then(() => {
              interaction.reply({
                embeds: [
                  successEmbed.setDescription(`You have successfully added ${MyEconomy.currency} ${amount} to ${SelectedUser}'s Bank`)
                ],
                ephemeral: true
              })
            })

          }
          break;
        case "balance": {
          let user = await User.findOne({
            serverID: guild.id,
            userID: SelectedUser.id
          });
          if (!user) return interaction.reply({
            embeds: [
              errorEmbed.setDescription("The user you have selected does not have an account set up in your economy.")
            ],
            ephemeral: true
          });
          if (amount <= 0) return interaction.reply({
            embeds: [
              errorEmbed.setDescription("You need to enter a number that is at least 1")
            ],
            ephemeral: true
          });

          await user.updateOne({
            $inc: {
              "wallet.balance": amount
            }
          }).then(() => {
            interaction.reply({
              embeds: [
                successEmbed.setDescription(`You have successfully added ${MyEconomy.currency} ${amount} to ${SelectedUser}'s Balance`)
              ],
              ephemeral: true
            })
          })
        }
        }

      }

      }
    } else {
      return interaction.reply("Please set up Galaxy Bot first. `/setup`");
    }
  },
};