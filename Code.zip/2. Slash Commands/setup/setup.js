const {
    Client,
    MessageEmbed,
    CommandInteraction,
    Message
} = require('discord.js');
const guildSchema = require("../../Storage/Schemas/guildSchema");

module.exports = {
    name: "setup",
    description: "Setup stream bot",
    permission: "ADMINISTRATOR",
    enabled: true,
    /**
     *
     * @param {CommandInteraction} interaction
     * @param {Client} client
     */
    async execute(interaction, client) {
        let myGuild = await guildSchema.findOne({
            serverID: interaction.guild.id
        });

        if (!myGuild) {

            await guildSchema.create({
                serverID: interaction.guild.id,
                ownerID: interaction.guild.ownerId,
            })

            interaction.reply({
                embeds: [
                    new MessageEmbed({
                        description: "You have successfully set up galaxy bot.",
                        color: "LUMINOUS_VIVID_PINK"
                    })
                ]
            })

        } else {
            return interaction.reply({
                content: "You have already set up Galaxy bot",
                ephemeral: true
            })
        }
    }
}