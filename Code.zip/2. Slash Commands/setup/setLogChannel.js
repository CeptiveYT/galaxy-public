const {
    Client,
    MessageEmbed,
    CommandInteraction,
    Message,
} = require("discord.js");
const guildSchema = require("../../Storage/Schemas/guildSchema");

module.exports = {
    name: "set-log-channel",
    description: "set the log channel for stream bot!",
    permission: "ADMINISTRATOR",
    enabled: true,
    options: [
        {
            name: "channel",
            description: "Select a channel to use as your log channel.",
            type: 7,
            required: true
        }
    ],
    /**
     *
     * @param {CommandInteraction} interaction
     * @param {Client} client
     */
    async execute(interaction, client) {
        let MyServer = await guildSchema.findOne({ serverID: interaction.guild.id });

        if (MyServer) {

            let channel = interaction.options.getChannel("channel");
            if (channel.type == "GUILD_TEXT") {

                if (channel.id == MyServer.logchannelID) return interaction.reply({ content: "You already have this channel set as your log channel.", ephemeral: true })

                await MyServer.updateOne({
                    logchannelID: channel.id
                })

                interaction.reply({ content: `You have set the log channel as ${channel}`, ephemeral: true })
            } else {
                return interaction.reply({ content: "Please provide a text based channel.", ephemeral: true })
            }

        } else {
            return interaction.reply("Please set up Galaxy Bot first. `/setup`");
        }

    }
};
