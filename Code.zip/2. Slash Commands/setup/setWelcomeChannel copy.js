const {
    Client,
    MessageEmbed,
    CommandInteraction,
    Message,
} = require("discord.js");
const guildSchema = require("../../Storage/Schemas/guildSchema");

module.exports = {
    name: "set-welcome-channel",
    description: "set the welcome channel for stream bot!",
    permission: "ADMINISTRATOR",
    enabled: true,
    options: [
        {
            name: "channel",
            description: "Select a channel to use as your welcome channel.",
            type: 7,
            required: true,
        },
    ],
    /**
     *
     * @param {CommandInteraction} interaction
     * @param {Client} client
     */
    async execute(interaction, client) {
        let MyServer = await guildSchema.findOne({
            serverID: interaction.guild.id,
        });

        if (MyServer) {
            let channel = interaction.options.getChannel("channel");
            if (channel.type == "GUILD_TEXT") {
                if (channel.id == MyServer.welcomechannelID)
                    return interaction.reply({
                        content:
                            "You already have this channel set as your welcome channel.",
                        ephemeral: true,
                    });

                await MyServer.updateOne({
                    welcomechannelID: channel.id,
                });

                interaction.reply({
                    content: `You have set the welcome channel as ${channel}`,
                    ephemeral: true,
                });
            } else {
                return interaction.reply({
                    content: "Please provide a text based channel.",
                    ephemeral: true,
                });
            }
        } else {
            return interaction.reply("Please set up Galaxy Bot first. `/setup`");
        }
    },
};
